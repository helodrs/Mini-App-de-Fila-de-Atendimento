from datetime import datetime
import sqlite3
from pathlib import Path

from flask import Flask, flash, redirect, render_template, request, url_for

app = Flask(__name__)
app.secret_key = "troque-esta-chave-em-producao"
BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "fila.db"


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS atendimentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                prioridade TEXT NOT NULL DEFAULT 'Normal'
                    CHECK (prioridade IN ('Normal', 'Preferencial')),
                status TEXT NOT NULL DEFAULT 'Aguardando'
                    CHECK (status IN ('Aguardando', 'Em Atendimento', 'Concluído', 'Cancelado')),
                criado_em TEXT NOT NULL,
                atualizado_em TEXT NOT NULL
            )
        """)


@app.template_filter("data_br")
def data_br(value):
    try:
        return datetime.fromisoformat(value).strftime("%d/%m/%Y %H:%M")
    except (TypeError, ValueError):
        return value


@app.route("/")
def index():
    with get_db() as db:
        fila = db.execute("""
            SELECT * FROM atendimentos
            WHERE status = 'Aguardando'
            ORDER BY CASE prioridade WHEN 'Preferencial' THEN 0 ELSE 1 END, id ASC
        """).fetchall()
        em_atendimento = db.execute("""
            SELECT * FROM atendimentos
            WHERE status = 'Em Atendimento'
            ORDER BY atualizado_em ASC
        """).fetchall()
        historico = db.execute("""
            SELECT * FROM atendimentos
            WHERE status IN ('Concluído', 'Cancelado')
            ORDER BY atualizado_em DESC, id DESC
            LIMIT 30
        """).fetchall()
    return render_template(
        "index.html",
        fila=fila,
        em_atendimento=em_atendimento,
        historico=historico
    )


@app.post("/cadastrar")
def cadastrar():
    nome = request.form.get("nome", "").strip()
    prioridade = request.form.get("prioridade", "Normal")
    if not nome:
        flash("Informe o nome do cliente.", "erro")
    elif prioridade not in ("Normal", "Preferencial"):
        flash("Prioridade inválida.", "erro")
    else:
        agora = datetime.now().isoformat(timespec="seconds")
        with get_db() as db:
            db.execute("""
                INSERT INTO atendimentos (nome, prioridade, status, criado_em, atualizado_em)
                VALUES (?, ?, 'Aguardando', ?, ?)
            """, (nome, prioridade, agora, agora))
        flash(f"{nome} foi adicionado(a) à fila.", "sucesso")
    return redirect(url_for("index"))


@app.post("/chamar-proximo")
def chamar_proximo():
    agora = datetime.now().isoformat(timespec="seconds")
    with get_db() as db:
        proximo = db.execute("""
            SELECT id, nome FROM atendimentos
            WHERE status = 'Aguardando'
            ORDER BY CASE prioridade WHEN 'Preferencial' THEN 0 ELSE 1 END, id ASC
            LIMIT 1
        """).fetchone()
        if proximo:
            db.execute("""
                UPDATE atendimentos
                SET status = 'Em Atendimento', atualizado_em = ?
                WHERE id = ? AND status = 'Aguardando'
            """, (agora, proximo["id"]))
            flash(f"Agora é a vez de {proximo['nome']}!", "sucesso")
        else:
            flash("Não há clientes aguardando.", "aviso")
    return redirect(url_for("index"))


@app.post("/status/<int:atendimento_id>")
def alterar_status(atendimento_id):
    novo_status = request.form.get("status")
    permitidos = ("Aguardando", "Em Atendimento", "Concluído", "Cancelado")
    if novo_status not in permitidos:
        flash("Status inválido.", "erro")
        return redirect(url_for("index"))

    agora = datetime.now().isoformat(timespec="seconds")
    with get_db() as db:
        cursor = db.execute("""
            UPDATE atendimentos SET status = ?, atualizado_em = ?
            WHERE id = ?
        """, (novo_status, agora, atendimento_id))
        if cursor.rowcount:
            flash("Status atualizado.", "sucesso")
        else:
            flash("Atendimento não encontrado.", "erro")
    return redirect(url_for("index"))


@app.post("/cancelar/<int:atendimento_id>")
def cancelar(atendimento_id):
    agora = datetime.now().isoformat(timespec="seconds")
    with get_db() as db:
        cursor = db.execute("""
            UPDATE atendimentos SET status = 'Cancelado', atualizado_em = ?
            WHERE id = ? AND status IN ('Aguardando', 'Em Atendimento')
        """, (agora, atendimento_id))
        if cursor.rowcount:
            flash("Atendimento cancelado.", "sucesso")
        else:
            flash("Não foi possível cancelar esse atendimento.", "aviso")
    return redirect(url_for("index"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
