# Fila & Companhia — Mini App de Fila de Atendimento

Aplicação web feita com **Python, Flask e SQLite** para cadastrar clientes, organizar a fila e acompanhar os atendimentos.

## Funcionalidades

- Cadastro de clientes com prioridade Normal ou Preferencial.
- Exibição da fila de espera.
- Chamada do próximo cliente: prioridade preferencial primeiro e, dentro de cada prioridade, ordem de chegada (FIFO).
- Alteração de status para Aguardando, Em Atendimento, Concluído ou Cancelado.
- Cancelamento de atendimentos.
- Histórico dos últimos 30 atendimentos concluídos ou cancelados.
- Atualização automática da página a cada 15 segundos.
- Banco SQLite criado automaticamente na primeira execução.

## Requisitos

- Python 3.10 ou superior
- pip

## Como executar

1. Baixe ou clone este repositório.
2. Abra o terminal na pasta do projeto.
3. (Opcional, mas recomendado) Crie e ative um ambiente virtual:

   **Windows**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

   **Linux/macOS**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

4. Instale as dependências:

   ```bash
   pip install -r requirements.txt
   ```

5. Inicie o sistema:

   ```bash
   python app.py
   ```

6. Abra no navegador o endereço indicado no terminal, normalmente:

   `http://127.0.0.1:5000`

O arquivo `fila.db` será criado automaticamente na pasta do projeto.

## Estrutura

```text
mini_fila_atendimento/
├── app.py
├── requirements.txt
├── README.md
├── fila.db              # criado automaticamente ao executar
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Regras da fila

- Clientes preferenciais são chamados antes dos clientes normais.
- Entre clientes com a mesma prioridade, quem chegou primeiro é chamado primeiro.
- Ao clicar em **Chamar próximo**, o primeiro cliente elegível muda para **Em Atendimento**.
- Atendimentos concluídos e cancelados permanecem no histórico.

## Publicar no GitHub

Crie um repositório no GitHub e, no terminal dentro da pasta do projeto, execute:

```bash
git init
git add .
git commit -m "Adiciona sistema de fila de atendimento"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
git push -u origin main
```

Substitua a URL de exemplo pela URL do seu repositório.

## Envio por e-mail

Depois de publicar, envie o link do repositório para `eduardo.hernandes@docente.senai.br`.
